# BlendArMocap processing pipeline via socket

### To be implemented